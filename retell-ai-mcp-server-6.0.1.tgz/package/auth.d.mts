import { IncomingMessage } from 'node:http';
import { ClientOptions } from 'retell-sdk';
import { McpOptions } from "./options.mjs";
export declare const parseClientAuthHeaders: (req: IncomingMessage, required?: boolean) => Partial<ClientOptions>;
export declare const getStainlessApiKey: (req: IncomingMessage, mcpOptions: McpOptions) => string | undefined;
//# sourceMappingURL=auth.d.mts.map