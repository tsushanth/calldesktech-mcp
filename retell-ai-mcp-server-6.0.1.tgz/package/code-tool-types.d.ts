import { ClientOptions } from 'retell-sdk';
export type WorkerInput = {
    project_name: string;
    code: string;
    client_opts: ClientOptions;
    intent?: string | undefined;
};
export type WorkerOutput = {
    is_error: boolean;
    result: unknown | null;
    log_lines: string[];
    err_lines: string[];
};
//# sourceMappingURL=code-tool-types.d.ts.map