import { McpOptions } from "./options.mjs";
export declare const launchStdioServer: (mcpOptions: McpOptions) => Promise<void>;
//# sourceMappingURL=stdio.d.mts.map