# Retell TypeScript MCP Server

## Installation

### Direct invocation

You can run the MCP Server directly via `npx`:

```sh
export RETELL_API_KEY="YOUR_RETELL_API_KEY"
npx -y @retell-ai/mcp-server@latest
```

### Via MCP Client

There is a partial list of existing clients at [modelcontextprotocol.io](https://modelcontextprotocol.io/clients). If you already
have a client, consult their documentation to install the MCP server.

For clients with a configuration JSON, it might look something like this:

```json
{
  "mcpServers": {
    "retell_sdk_api": {
      "command": "npx",
      "args": ["-y", "@retell-ai/mcp-server"],
      "env": {
        "RETELL_API_KEY": "YOUR_RETELL_API_KEY"
      }
    }
  }
}
```

### Cursor

If you use Cursor, you can install the MCP server by using the button below. You will need to set your environment variables
in Cursor's `mcp.json`, which can be found in Cursor Settings > Tools & MCP > New MCP Server.

[![Add to Cursor](https://cursor.com/deeplink/mcp-install-dark.svg)](https://cursor.com/en-US/install-mcp?name=%40retell-ai%2Fmcp-server&config=eyJjb21tYW5kIjoibnB4IiwiYXJncyI6WyIteSIsIkByZXRlbGwtYWkvbWNwLXNlcnZlciJdLCJlbnYiOnsiUkVURUxMX0FQSV9LRVkiOiJZT1VSX1JFVEVMTF9BUElfS0VZIn19)

### VS Code

If you use MCP, you can install the MCP server by clicking the link below. You will need to set your environment variables
in VS Code's `mcp.json`, which can be found via Command Palette > MCP: Open User Configuration.

[Open VS Code](https://vscode.stainless.com/mcp/%7B%22name%22%3A%22%40retell-ai%2Fmcp-server%22%2C%22command%22%3A%22npx%22%2C%22args%22%3A%5B%22-y%22%2C%22%40retell-ai%2Fmcp-server%22%5D%2C%22env%22%3A%7B%22RETELL_API_KEY%22%3A%22YOUR_RETELL_API_KEY%22%7D%7D)

### Claude Code

If you use Claude Code, you can install the MCP server by running the command below in your terminal. You will need to set your
environment variables in Claude Code's `.claude.json`, which can be found in your home directory.

```
claude mcp add retell_ai_mcp_server_api --env RETELL_API_KEY="YOUR_RETELL_API_KEY" -- npx -y @retell-ai/mcp-server
```

## Code Mode

This MCP server is built on the "Code Mode" tool scheme. In this MCP Server,
your agent will write code against the TypeScript SDK, which will then be executed in a
sandbox. To accomplish this, the server will expose two tools to your agent:

- The first tool is a docs search tool, which can be used to generically query for
  documentation about your API/SDK.

- The second tool is a code tool, where the agent can write code against the TypeScript SDK.
  The code is executed in a sandbox whose filesystem and network access are restricted to
  what the SDK needs — see "Where code runs" below. Then, anything the code returns or
  prints will be returned to the agent as the result of the tool call.

Using this scheme, agents are capable of performing very complex tasks deterministically
and repeatably.

### Where code runs

This server runs code locally. Each code tool call is executed in a Deno subprocess on the
same machine as the MCP server, restricted to reading the server's own files and to making
network requests to your API host.

Deno must be installed for the code tool to work. Install it from https://deno.land, or add it
to the MCP server's dependencies with `npm install deno`.

## Running remotely

Launching the client with `--transport=http` launches the server as a remote server using Streamable HTTP transport. The `--port` setting can choose the port it will run on, and the `--socket` setting allows it to run on a Unix socket.

Authorization can be provided via the `Authorization` header using the Bearer scheme.

Additionally, authorization can be provided via the following headers:
| Header | Equivalent client option | Security scheme |
| ------------------ | ------------------------ | --------------- |
| `x-retell-api-key` | `apiKey` | api_key |

A configuration JSON for this server might look like this, assuming the server is hosted at `http://localhost:3000`:

```json
{
  "mcpServers": {
    "retell_sdk_api": {
      "url": "http://localhost:3000",
      "headers": {
        "Authorization": "Bearer <auth value>"
      }
    }
  }
}
```
