export type CLIOptions = McpOptions & {
    debug: boolean;
    logFormat: 'json' | 'pretty';
    transport: 'stdio' | 'http';
    port: number | undefined;
    socket: string | undefined;
};
export type McpOptions = {
    includeCodeTool?: boolean | undefined;
    includeDocsTools?: boolean | undefined;
    stainlessApiKey?: string | undefined;
    docsSearchMode?: 'local' | undefined;
    docsDir?: string | undefined;
    codeAllowHttpGets?: boolean | undefined;
    codeAllowedMethods?: string[] | undefined;
    codeBlockedMethods?: string[] | undefined;
    codeExecutionMode: McpCodeExecutionMode;
    customInstructionsPath?: string | undefined;
};
export type McpCodeExecutionMode = 'local';
export declare function parseCLIOptions(): CLIOptions;
export declare function parseQueryOptions(defaultOptions: McpOptions, query: unknown): McpOptions;
//# sourceMappingURL=options.d.mts.map