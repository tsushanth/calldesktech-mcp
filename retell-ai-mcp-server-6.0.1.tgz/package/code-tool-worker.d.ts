declare const _default: {
    fetch: (req: Request) => Promise<Response>;
};
export default _default;
//# sourceMappingURL=code-tool-worker.d.ts.map