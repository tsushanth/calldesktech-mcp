import { Tool } from '@modelcontextprotocol/sdk/types.js';
import { Metadata, McpRequestContext } from "./types.js";
import type { LocalDocsSearch } from "./local-docs-search.js";
export declare const metadata: Metadata;
export declare const tool: Tool;
export declare function setLocalSearch(search: LocalDocsSearch): void;
export declare const handler: ({ reqContext, args, }: {
    reqContext: McpRequestContext;
    args: Record<string, unknown> | undefined;
}) => Promise<import("./types.js").ToolCallResult>;
declare const _default: {
    metadata: Metadata;
    tool: {
        inputSchema: {
            [x: string]: unknown;
            type: "object";
            properties?: {
                [x: string]: object;
            } | undefined;
            required?: string[] | undefined;
        };
        name: string;
        description?: string | undefined;
        outputSchema?: {
            [x: string]: unknown;
            type: "object";
            properties?: {
                [x: string]: object;
            } | undefined;
            required?: string[] | undefined;
        } | undefined;
        annotations?: {
            title?: string | undefined;
            readOnlyHint?: boolean | undefined;
            destructiveHint?: boolean | undefined;
            idempotentHint?: boolean | undefined;
            openWorldHint?: boolean | undefined;
        } | undefined;
        execution?: {
            taskSupport?: "optional" | "required" | "forbidden" | undefined;
        } | undefined;
        _meta?: {
            [x: string]: unknown;
        } | undefined;
        icons?: {
            src: string;
            mimeType?: string | undefined;
            sizes?: string[] | undefined;
            theme?: "light" | "dark" | undefined;
        }[] | undefined;
        title?: string | undefined;
    };
    handler: ({ reqContext, args, }: {
        reqContext: McpRequestContext;
        args: Record<string, unknown> | undefined;
    }) => Promise<import("./types.js").ToolCallResult>;
};
export default _default;
//# sourceMappingURL=docs-search-tool.d.ts.map