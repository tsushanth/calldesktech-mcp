type SearchResult = {
    results: (string | Record<string, unknown>)[];
};
/**
 * Self-contained local search engine backed by MiniSearch.
 * Method data is embedded at SDK build time; prose documents
 * can be loaded from an optional docs directory at runtime.
 */
export declare class LocalDocsSearch {
    private methodIndex;
    private proseIndex;
    private constructor();
    static create(opts?: {
        docsDir?: string;
    }): Promise<LocalDocsSearch>;
    search(props: {
        query: string;
        language?: string;
        detail?: string;
        maxResults?: number;
        maxLength?: number;
    }): SearchResult;
    private indexMethods;
    private loadDocsDirectory;
    private indexProse;
}
export {};
//# sourceMappingURL=local-docs-search.d.mts.map