import { McpOptions } from "./options.js";
export declare const launchStdioServer: (mcpOptions: McpOptions) => Promise<void>;
//# sourceMappingURL=stdio.d.ts.map