import { type Level, type Logger } from 'pino';
export declare function configureLogger({ level, pretty: usePretty }: {
    level: Level;
    pretty: boolean;
}): void;
export declare function getLogger(): Logger;
//# sourceMappingURL=logger.d.mts.map