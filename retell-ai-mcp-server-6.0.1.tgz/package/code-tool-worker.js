"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_path_1 = __importDefault(require("node:path"));
const node_util_1 = __importDefault(require("node:util"));
const fuse_js_1 = __importDefault(require("fuse.js"));
const typescript_1 = __importDefault(require("typescript"));
const retell_sdk_1 = require("retell-sdk");
async function tseval(code) {
    return Promise.resolve(`${'data:application/typescript;charset=utf-8;base64,' + Buffer.from(code).toString('base64')}`).then(s => __importStar(require(s)));
}
function getRunFunctionSource(code) {
    const sourceFile = typescript_1.default.createSourceFile('code.ts', code, typescript_1.default.ScriptTarget.Latest, true);
    const printer = typescript_1.default.createPrinter();
    for (const statement of sourceFile.statements) {
        // Check for top-level function declarations
        if (typescript_1.default.isFunctionDeclaration(statement)) {
            if (statement.name?.text === 'run') {
                return {
                    type: 'declaration',
                    client: statement.parameters[0]?.name.getText(),
                    code: printer.printNode(typescript_1.default.EmitHint.Unspecified, statement.body, sourceFile),
                };
            }
        }
        // Check for variable declarations: const run = () => {} or const run = function() {}
        if (typescript_1.default.isVariableStatement(statement)) {
            for (const declaration of statement.declarationList.declarations) {
                if (typescript_1.default.isIdentifier(declaration.name) &&
                    declaration.name.text === 'run' &&
                    // Check if it's initialized with a function
                    declaration.initializer &&
                    (typescript_1.default.isFunctionExpression(declaration.initializer) || typescript_1.default.isArrowFunction(declaration.initializer))) {
                    return {
                        type: 'expression',
                        client: declaration.initializer.parameters[0]?.name.getText(),
                        code: printer.printNode(typescript_1.default.EmitHint.Unspecified, declaration.initializer, sourceFile),
                    };
                }
            }
        }
    }
    return null;
}
function getTSDiagnostics(code) {
    const functionSource = getRunFunctionSource(code);
    const codeWithImport = [
        'import { Retell } from "retell-sdk";',
        functionSource.type === 'declaration' ?
            `async function run(${functionSource.client}: Retell)`
            : `const run: (${functionSource.client}: Retell) => Promise<unknown> =`,
        functionSource.code,
    ].join('\n');
    const sourcePath = node_path_1.default.resolve('code.ts');
    const ast = typescript_1.default.createSourceFile(sourcePath, codeWithImport, typescript_1.default.ScriptTarget.Latest, true);
    const options = typescript_1.default.getDefaultCompilerOptions();
    options.target = typescript_1.default.ScriptTarget.Latest;
    options.module = typescript_1.default.ModuleKind.NodeNext;
    options.moduleResolution = typescript_1.default.ModuleResolutionKind.NodeNext;
    const host = typescript_1.default.createCompilerHost(options, true);
    const newHost = {
        ...host,
        getSourceFile: (...args) => {
            if (node_path_1.default.resolve(args[0]) === sourcePath) {
                return ast;
            }
            return host.getSourceFile(...args);
        },
        readFile: (...args) => {
            if (node_path_1.default.resolve(args[0]) === sourcePath) {
                return codeWithImport;
            }
            return host.readFile(...args);
        },
        fileExists: (...args) => {
            if (node_path_1.default.resolve(args[0]) === sourcePath) {
                return true;
            }
            return host.fileExists(...args);
        },
    };
    const program = typescript_1.default.createProgram({
        options,
        rootNames: [sourcePath],
        host: newHost,
    });
    const diagnostics = typescript_1.default.getPreEmitDiagnostics(program, ast);
    return diagnostics.map((d) => {
        const message = typescript_1.default.flattenDiagnosticMessageText(d.messageText, '\n');
        if (!d.file || !d.start)
            return `- ${message}`;
        const { line: lineNumber } = typescript_1.default.getLineAndCharacterOfPosition(d.file, d.start);
        const line = codeWithImport.split('\n').at(lineNumber)?.trim();
        return line ? `- ${message}\n    ${line}` : `- ${message}`;
    });
}
const fuse = new fuse_js_1.default([
    'client.call.createPhoneCall',
    'client.call.createWebCall',
    'client.call.delete',
    'client.call.list',
    'client.call.listenLive',
    'client.call.registerPhoneCall',
    'client.call.rerunAnalysis',
    'client.call.retrieve',
    'client.call.stop',
    'client.call.takeOverLive',
    'client.call.update',
    'client.call.updateLive',
    'client.chat.create',
    'client.chat.createChatCompletion',
    'client.chat.createSMSChat',
    'client.chat.delete',
    'client.chat.end',
    'client.chat.list',
    'client.chat.rerunAnalysis',
    'client.chat.retrieve',
    'client.chat.update',
    'client.phoneNumber.create',
    'client.phoneNumber.delete',
    'client.phoneNumber.import',
    'client.phoneNumber.list',
    'client.phoneNumber.retrieve',
    'client.phoneNumber.update',
    'client.agent.create',
    'client.agent.createVersion',
    'client.agent.delete',
    'client.agent.deleteVersion',
    'client.agent.list',
    'client.agent.listVersions',
    'client.agent.publish',
    'client.agent.repair',
    'client.agent.retrieve',
    'client.agent.update',
    'client.chatAgent.create',
    'client.chatAgent.createVersion',
    'client.chatAgent.delete',
    'client.chatAgent.deleteVersion',
    'client.chatAgent.list',
    'client.chatAgent.publish',
    'client.chatAgent.retrieve',
    'client.chatAgent.update',
    'client.llm.create',
    'client.llm.delete',
    'client.llm.list',
    'client.llm.retrieve',
    'client.llm.update',
    'client.conversationFlow.create',
    'client.conversationFlow.delete',
    'client.conversationFlow.list',
    'client.conversationFlow.retrieve',
    'client.conversationFlow.update',
    'client.conversationFlowComponent.create',
    'client.conversationFlowComponent.delete',
    'client.conversationFlowComponent.list',
    'client.conversationFlowComponent.retrieve',
    'client.conversationFlowComponent.update',
    'client.knowledgeBase.addSources',
    'client.knowledgeBase.create',
    'client.knowledgeBase.delete',
    'client.knowledgeBase.deleteSource',
    'client.knowledgeBase.list',
    'client.knowledgeBase.retrieve',
    'client.voice.addResource',
    'client.voice.clone',
    'client.voice.list',
    'client.voice.retrieve',
    'client.voice.search',
    'client.asset.create',
    'client.concurrency.retrieve',
    'client.identity.retrieve',
    'client.exportRequest.list',
    'client.batchCall.createBatchCall',
    'client.tests.createBatchTest',
    'client.tests.createTestCaseDefinition',
    'client.tests.deleteTestCaseDefinition',
    'client.tests.getBatchTest',
    'client.tests.getTestCaseDefinition',
    'client.tests.getTestRun',
    'client.tests.listBatchTests',
    'client.tests.listTestCaseDefinitions',
    'client.tests.listTestRuns',
    'client.tests.updateTestCaseDefinition',
    'client.playground.completion',
    'client.mcpTool.getMcpTools',
    'client.contact.backfillAnalysisData',
    'client.contact.create',
    'client.contact.createImport',
    'client.contact.delete',
    'client.contact.get',
    'client.contact.getBackfillJobStatus',
    'client.contact.getByPhone',
    'client.contact.getImport',
    'client.contact.list',
    'client.contact.listConversations',
    'client.contact.update',
    'client.contact.uploadImportFile',
    'client.app.create',
    'client.app.delete',
    'client.app.get',
    'client.app.list',
    'client.app.listUsages',
    'client.app.testAuth',
    'client.app.update',
    'client.crm.getConfig',
    'client.crm.getSchema',
    'client.crm.getSyncJobStatus',
    'client.crm.runSyncJob',
    'client.crm.updateConfig',
], { threshold: 1, shouldSort: true });
function getMethodSuggestions(fullyQualifiedMethodName) {
    return fuse
        .search(fullyQualifiedMethodName)
        .map(({ item }) => item)
        .slice(0, 5);
}
const proxyToObj = new WeakMap();
const objToProxy = new WeakMap();
function makeSdkProxy(obj, { path, isBelievedBad = false }) {
    let proxy = objToProxy.get(obj);
    if (!proxy) {
        proxy = new Proxy(obj, {
            get(target, prop, receiver) {
                const propPath = [...path, String(prop)];
                const value = Reflect.get(target, prop, receiver);
                if (isBelievedBad || (!(prop in target) && value === undefined)) {
                    // If we're accessing a path that doesn't exist, it will probably eventually error.
                    // Let's proxy it and mark it bad so that we can control the error message.
                    // We proxy an empty class so that an invocation or construction attempt is possible.
                    return makeSdkProxy(class {
                    }, { path: propPath, isBelievedBad: true });
                }
                if (value !== null && (typeof value === 'object' || typeof value === 'function')) {
                    return makeSdkProxy(value, { path: propPath, isBelievedBad });
                }
                return value;
            },
            apply(target, thisArg, args) {
                if (isBelievedBad || typeof target !== 'function') {
                    const fullyQualifiedMethodName = path.join('.');
                    const suggestions = getMethodSuggestions(fullyQualifiedMethodName);
                    throw new Error(`${fullyQualifiedMethodName} is not a function. Did you mean: ${suggestions.join(', ')}`);
                }
                return Reflect.apply(target, proxyToObj.get(thisArg) ?? thisArg, args);
            },
            construct(target, args, newTarget) {
                if (isBelievedBad || typeof target !== 'function') {
                    const fullyQualifiedMethodName = path.join('.');
                    const suggestions = getMethodSuggestions(fullyQualifiedMethodName);
                    throw new Error(`${fullyQualifiedMethodName} is not a constructor. Did you mean: ${suggestions.join(', ')}`);
                }
                return Reflect.construct(target, args, newTarget);
            },
        });
        objToProxy.set(obj, proxy);
        proxyToObj.set(proxy, obj);
    }
    return proxy;
}
function parseError(code, error) {
    if (!(error instanceof Error))
        return;
    const cause = error.cause instanceof Error ? `: ${error.cause.message}` : '';
    const message = error.name ? `${error.name}: ${error.message}${cause}` : `${error.message}${cause}`;
    try {
        // Deno uses V8; the first "<anonymous>:LINE:COLUMN" is the top of stack.
        const lineNumber = error.stack?.match(/<anonymous>:([0-9]+):[0-9]+/)?.[1];
        // -1 for the zero-based indexing
        const line = lineNumber &&
            code
                .split('\n')
                .at(parseInt(lineNumber, 10) - 1)
                ?.trim();
        return line ? `${message}\n  at line ${lineNumber}\n    ${line}` : message;
    }
    catch {
        return message;
    }
}
const fetch = async (req) => {
    const { opts, code } = (await req.json());
    const runFunctionSource = code ? getRunFunctionSource(code) : null;
    if (!runFunctionSource) {
        const message = code ?
            'The code is missing a top-level `run` function.'
            : 'The code argument is missing. Provide one containing a top-level `run` function.';
        return Response.json({
            is_error: true,
            result: `${message} Write code within this template:\n\n\`\`\`\nasync function run(client) {\n  // Fill this out\n}\n\`\`\``,
            log_lines: [],
            err_lines: [],
        }, { status: 400, statusText: 'Code execution error' });
    }
    const diagnostics = getTSDiagnostics(code);
    if (diagnostics.length > 0) {
        return Response.json({
            is_error: true,
            result: `The code contains TypeScript diagnostics:\n${diagnostics.join('\n')}`,
            log_lines: [],
            err_lines: [],
        }, { status: 400, statusText: 'Code execution error' });
    }
    const client = new retell_sdk_1.Retell({
        ...opts,
    });
    const log_lines = [];
    const err_lines = [];
    const originalConsole = globalThis.console;
    globalThis.console = {
        ...originalConsole,
        log: (...args) => {
            log_lines.push(node_util_1.default.format(...args));
        },
        error: (...args) => {
            err_lines.push(node_util_1.default.format(...args));
        },
    };
    try {
        let run_ = async (client) => { };
        run_ = (await tseval(`${code}\nexport default run;`)).default;
        const result = await run_(makeSdkProxy(client, { path: ['client'] }));
        return Response.json({
            is_error: false,
            result,
            log_lines,
            err_lines,
        });
    }
    catch (e) {
        return Response.json({
            is_error: true,
            result: parseError(code, e),
            log_lines,
            err_lines,
        }, { status: 400, statusText: 'Code execution error' });
    }
    finally {
        globalThis.console = originalConsole;
    }
};
exports.default = { fetch };
//# sourceMappingURL=code-tool-worker.js.map