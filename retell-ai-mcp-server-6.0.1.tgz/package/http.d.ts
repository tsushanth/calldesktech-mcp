import { ClientOptions } from 'retell-sdk';
import express from 'express';
import { McpOptions } from "./options.js";
export declare const streamableHTTPApp: ({ clientOptions, mcpOptions, }: {
    clientOptions?: ClientOptions;
    mcpOptions: McpOptions;
}) => express.Express;
export declare const launchStreamableHTTPServer: ({ mcpOptions, port, }: {
    mcpOptions: McpOptions;
    port: number | string | undefined;
}) => Promise<void>;
//# sourceMappingURL=http.d.ts.map