import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { ClientOptions } from 'retell-sdk';
import { McpOptions } from "./options.js";
import { HandlerFunction, McpRequestContext, ToolCallResult, McpTool } from "./types.js";
export declare const newMcpServer: ({ stainlessApiKey, customInstructionsPath, }: {
    stainlessApiKey?: string | undefined;
    customInstructionsPath?: string | undefined;
}) => Promise<McpServer>;
/**
 * Initializes the provided MCP Server with the given tools and handlers.
 * If not provided, the default client, tools and handlers will be used.
 */
export declare function initMcpServer(params: {
    server: Server | McpServer;
    clientOptions?: ClientOptions;
    mcpOptions?: McpOptions;
    stainlessApiKey?: string | undefined;
    upstreamClientEnvs?: Record<string, string> | undefined;
    mcpSessionId?: string | undefined;
    mcpClientInfo?: {
        name: string;
        version: string;
    } | undefined;
}): Promise<void>;
/**
 * Selects the tools to include in the MCP Server based on the provided options.
 */
export declare function selectTools(options?: McpOptions): McpTool[];
/**
 * Runs the provided handler with the given client and arguments.
 */
export declare function executeHandler({ handler, reqContext, args, }: {
    handler: HandlerFunction;
    reqContext: McpRequestContext;
    args: Record<string, unknown> | undefined;
}): Promise<ToolCallResult>;
//# sourceMappingURL=server.d.ts.map