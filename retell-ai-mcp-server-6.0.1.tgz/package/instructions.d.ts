export declare function getInstructions({ stainlessApiKey, customInstructionsPath, }: {
    stainlessApiKey?: string | undefined;
    customInstructionsPath?: string | undefined;
}): Promise<string>;
//# sourceMappingURL=instructions.d.ts.map