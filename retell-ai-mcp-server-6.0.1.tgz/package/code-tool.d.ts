import { McpTool } from "./types.js";
import { SdkMethod } from "./methods.js";
import { McpCodeExecutionMode } from "./options.js";
/**
 * A tool that runs code against a copy of the SDK.
 *
 * Instead of exposing every endpoint as its own tool, which uses up too many tokens for LLMs to use at once,
 * we expose a single tool that can be used to search for endpoints by name, resource, operation, or tag, and then
 * a generic endpoint that can be used to invoke any endpoint with the provided arguments.
 *
 * @param blockedMethods - The methods to block for code execution. Blocking is done by simple string
 * matching, so it is not secure against obfuscation. For stronger security, block in the downstream API
 * with limited API keys.
 * @param codeExecutionMode - Whether to execute code in a local Deno environment or in a remote
 * sandbox environment hosted by Stainless.
 */
export declare function codeTool({ blockedMethods, codeExecutionMode, }: {
    blockedMethods: SdkMethod[] | undefined;
    codeExecutionMode: McpCodeExecutionMode;
}): McpTool;
//# sourceMappingURL=code-tool.d.ts.map