import { McpOptions } from "./options.js";
export type SdkMethod = {
    clientCallName: string;
    fullyQualifiedName: string;
    httpMethod?: 'get' | 'post' | 'put' | 'patch' | 'delete' | 'query';
    httpPath?: string;
};
export declare const sdkMethods: SdkMethod[];
export declare function blockedMethodsForCodeTool(options: McpOptions | undefined): SdkMethod[] | undefined;
//# sourceMappingURL=methods.d.ts.map