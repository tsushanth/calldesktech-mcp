export declare const readEnv: (env: string) => string | undefined;
export declare const readEnvOrError: (env: string) => string;
export declare const requireValue: <T>(value: T | undefined, description: string) => T;
//# sourceMappingURL=util.d.ts.map