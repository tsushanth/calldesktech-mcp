"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWorkerPath = getWorkerPath;
function getWorkerPath() {
    return require.resolve('./code-tool-worker.mjs');
}
//# sourceMappingURL=code-tool-paths.cjs.map