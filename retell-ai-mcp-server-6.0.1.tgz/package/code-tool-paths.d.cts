export declare function getWorkerPath(): string;
//# sourceMappingURL=code-tool-paths.d.cts.map