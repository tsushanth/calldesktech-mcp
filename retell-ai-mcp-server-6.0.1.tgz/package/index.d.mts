#!/usr/bin/env node
export {};
//# sourceMappingURL=index.d.mts.map